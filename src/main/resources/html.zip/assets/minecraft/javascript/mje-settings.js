function setVersion(version) {
    document.getElementById("mje-version").innerText = version;
}