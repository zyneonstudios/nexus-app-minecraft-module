function enableMicrosoftLogin() {
    const button = document.getElementById("mje-ms-login-button");
    if(!button.classList.contains("active")) {
        button.classList.add("active");
    }
    button.onclick = function () {
        connector("java.auth.login");
    };
}

function disableMicrosoftLogin() {
    const button = document.getElementById("mje-ms-login-button");
    if(button.classList.contains("active")) {
        button.classList.remove("active");
    }
    button.onclick = function () {};
}

function initLogin() {
    const urlParams = new URLSearchParams(window.location.search);
    if(urlParams.get("enable")) {
        if(urlParams.get("enable")==="true") {
            enableMicrosoftLogin();
            return;
        }
    }
    connector("java.init.auth.login");
    setInterval(refresh, 5000);
}

function refresh() {
    connector("java.init.auth.login");
}